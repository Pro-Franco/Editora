from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class Autor(db.Model):
    __tablename__ = 'autores'
    
    autor_id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    data_nascimento = db.Column(db.Date)
    nacionalidade = db.Column(db.String(50))
    livros = db.relationship('Livro', secondary='livro_autor', backref='autores')
    
    def __repr__(self):
        return f'<Autor {self.nome}>'

class Livro(db.Model):
    __tablename__ = 'livros'
    
    livro_id = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(200), nullable=False)
    isbn = db.Column(db.String(13), unique=True, nullable=False)
    data_publicacao = db.Column(db.Date)
    genero = db.Column(db.String(50))
    
    def __repr__(self):
        return f'<Livro {self.titulo}>'

livro_autor = db.Table('livro_autor',
    db.Column('livro_id', db.Integer, db.ForeignKey('livros.livro_id'), primary_key=True),
    db.Column('autor_id', db.Integer, db.ForeignKey('autores.autor_id'), primary_key=True)
)

class Cliente(db.Model):
    __tablename__ = 'clientes'
    
    cliente_id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    data_cadastro = db.Column(db.DateTime, default=datetime.utcnow)
    vendas = db.relationship('Venda', backref='cliente', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Cliente {self.nome}>'

class Venda(db.Model):
    __tablename__ = 'vendas'
    
    venda_id = db.Column(db.Integer, primary_key=True)
    cliente_id = db.Column(db.Integer, db.ForeignKey('clientes.cliente_id'), nullable=False)
    data_venda = db.Column(db.Date, nullable=False)
    valor_total = db.Column(db.Numeric(10, 2), nullable=False)
    itens = db.relationship('VendaItem', backref='venda', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Venda {self.venda_id}>'

class VendaItem(db.Model):
    __tablename__ = 'vendas_item'
    
    venda_item_id = db.Column(db.Integer, primary_key=True)
    venda_id = db.Column(db.Integer, db.ForeignKey('vendas.venda_id'), nullable=False)
    livro_id = db.Column(db.Integer, db.ForeignKey('livros.livro_id'), nullable=False)
    quantidade = db.Column(db.Integer, nullable=False)
    preco_unitario = db.Column(db.Numeric(10, 2), nullable=False)
    livro = db.relationship('Livro')
    
    def __repr__(self):
        return f'<VendaItem {self.venda_item_id}>'