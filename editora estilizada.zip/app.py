from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from datetime import datetime, date
from decimal import Decimal
from models import db, Autor, Livro, Cliente, Venda, VendaItem, livro_autor
from config import Config
import os

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)

with app.app_context():
    db.create_all()

# ===== ROTAS AUTORES =====
@app.route('/')
def index():
    """Página inicial com estatísticas"""
    total_autores = Autor.query.count()
    total_livros = Livro.query.count()
    total_clientes = Cliente.query.count()
    total_vendas = db.session.query(db.func.sum(Venda.valor_total)).scalar() or 0
    
    return render_template('index.html',
        total_autores=total_autores,
        total_livros=total_livros,
        total_clientes=total_clientes,
        total_vendas=total_vendas
    )

@app.route('/autores')
def listar_autores():
    """Lista todos os autores"""
    autores = Autor.query.all()
    return render_template('autores.html', autores=autores)

@app.route('/autores/novo', methods=['GET', 'POST'])
def novo_autor():
    """Criar novo autor"""
    if request.method == 'POST':
        nome = request.form.get('nome')
        data_nascimento = request.form.get('data_nascimento')
        nacionalidade = request.form.get('nacionalidade')
        
        if not nome:
            flash('Nome é obrigatório', 'error')
            return redirect(url_for('novo_autor'))
        
        autor = Autor(
            nome=nome,
            data_nascimento=datetime.strptime(data_nascimento, '%Y-%m-%d').date() if data_nascimento else None,
            nacionalidade=nacionalidade
        )
        db.session.add(autor)
        db.session.commit()
        flash(f'Autor {nome} criado com sucesso!', 'success')
        return redirect(url_for('listar_autores'))
    
    return render_template('novo_autor.html')

@app.route('/autores/<int:id>/editar', methods=['GET', 'POST'])
def editar_autor(id):
    """Editar autor existente"""
    autor = Autor.query.get_or_404(id)
    if request.method == 'POST':
        autor.nome = request.form.get('nome')
        data_nascimento = request.form.get('data_nascimento')
        autor.data_nascimento = datetime.strptime(data_nascimento, '%Y-%m-%d').date() if data_nascimento else None
        autor.nacionalidade = request.form.get('nacionalidade')
        
        db.session.commit()
        flash('Autor atualizado com sucesso!', 'success')
        return redirect(url_for('listar_autores'))
    
    return render_template('editar_autor.html', autor=autor)

@app.route('/autores/<int:id>/deletar', methods=['POST'])
def deletar_autor(id):
    """Deletar autor"""
    autor = Autor.query.get_or_404(id)
    db.session.delete(autor)
    db.session.commit()
    flash('Autor deletado com sucesso!', 'success')
    return redirect(url_for('listar_autores'))

# ===== ROTAS LIVROS =====
@app.route('/livros')
def listar_livros():
    """Lista todos os livros"""
    livros = Livro.query.all()
    return render_template('livros.html', livros=livros)

@app.route('/livros/novo', methods=['GET', 'POST'])
def novo_livro():
    """Criar novo livro"""
    try:
        if request.method == 'POST':
            titulo = request.form.get('titulo')
            isbn = request.form.get('isbn')
            data_publicacao = request.form.get('data_publicacao')
            genero = request.form.get('genero')
            autores_ids = request.form.getlist('autores')
            
            if not titulo or not isbn:
                flash('Título e ISBN são obrigatórios', 'error')
                return redirect(url_for('novo_livro'))
            
            # Tratamento para data vazia
            data_publicacao_obj = None
            if data_publicacao:
                try:
                    data_publicacao_obj = datetime.strptime(data_publicacao, '%Y-%m-%d').date()
                except ValueError:
                    flash('Formato de data inválido', 'error')
                    return redirect(url_for('novo_livro'))
            
            livro = Livro(
                titulo=titulo,
                isbn=isbn,
                data_publicacao=data_publicacao_obj,
                genero=genero
            )
            
            for autor_id in autores_ids:
                autor = Autor.query.get(autor_id)
                if autor:
                    livro.autores.append(autor)
            
            db.session.add(livro)
            db.session.commit()
            flash(f'Livro {titulo} criado com sucesso!', 'success')
            return redirect(url_for('listar_livros'))
        
        autores = Autor.query.all()
        return render_template('novo_livro.html', autores=autores)
    
    except Exception as e:
        print(f"Erro: {e}")  # Isso aparecerá no terminal
        flash(f'Erro ao processar a requisição: {str(e)}', 'error')
        return redirect(url_for('listar_livros'))

@app.route('/livros/<int:id>/editar', methods=['GET', 'POST'])
def editar_livro(id):
    """Editar livro existente"""
    livro = Livro.query.get_or_404(id)
    if request.method == 'POST':
        livro.titulo = request.form.get('titulo')
        livro.isbn = request.form.get('isbn')
        data_publicacao = request.form.get('data_publicacao')
        livro.data_publicacao = datetime.strptime(data_publicacao, '%Y-%m-%d').date() if data_publicacao else None
        livro.genero = request.form.get('genero')
        
        livro.autores.clear()
        autores_ids = request.form.getlist('autores')
        for autor_id in autores_ids:
            autor = Autor.query.get(autor_id)
            if autor:
                livro.autores.append(autor)
        
        db.session.commit()
        flash('Livro atualizado com sucesso!', 'success')
        return redirect(url_for('listar_livros'))
    
    autores = Autor.query.all()
    return render_template('editar_livro.html', livro=livro, autores=autores)

@app.route('/livros/<int:id>/deletar', methods=['POST'])
def deletar_livro(id):
    """Deletar livro"""
    livro = Livro.query.get_or_404(id)
    db.session.delete(livro)
    db.session.commit()
    flash('Livro deletado com sucesso!', 'success')
    return redirect(url_for('listar_livros'))

# ===== ROTAS CLIENTES =====
@app.route('/clientes')
def listar_clientes():
    """Lista todos os clientes"""
    clientes = Cliente.query.all()
    return render_template('clientes.html', clientes=clientes)

@app.route('/clientes/novo', methods=['GET', 'POST'])
def novo_cliente():
    """Criar novo cliente"""
    if request.method == 'POST':
        nome = request.form.get('nome')
        email = request.form.get('email')
        
        if not nome or not email:
            flash('Nome e email são obrigatórios', 'error')
            return redirect(url_for('novo_cliente'))
        
        cliente = Cliente(nome=nome, email=email)
        db.session.add(cliente)
        db.session.commit()
        flash(f'Cliente {nome} criado com sucesso!', 'success')
        return redirect(url_for('listar_clientes'))
    
    return render_template('novo_cliente.html')

@app.route('/clientes/<int:id>/editar', methods=['GET', 'POST'])
def editar_cliente(id):
    """Editar cliente existente"""
    cliente = Cliente.query.get_or_404(id)
    if request.method == 'POST':
        cliente.nome = request.form.get('nome')
        cliente.email = request.form.get('email')
        
        db.session.commit()
        flash('Cliente atualizado com sucesso!', 'success')
        return redirect(url_for('listar_clientes'))
    
    return render_template('editar_cliente.html', cliente=cliente)

@app.route('/clientes/<int:id>/deletar', methods=['POST'])
def deletar_cliente(id):
    """Deletar cliente"""
    cliente = Cliente.query.get_or_404(id)
    db.session.delete(cliente)
    db.session.commit()
    flash('Cliente deletado com sucesso!', 'success')
    return redirect(url_for('listar_clientes'))

# ===== ROTAS VENDAS =====
@app.route('/vendas')
def listar_vendas():
    """Lista todas as vendas"""
    vendas = Venda.query.all()
    return render_template('vendas.html', vendas=vendas)

@app.route('/vendas/nova', methods=['GET', 'POST'])
def nova_venda():
    """Criar nova venda"""
    if request.method == 'POST':
        cliente_id = request.form.get('cliente_id')
        data_venda = request.form.get('data_venda')
        
        if not cliente_id or not data_venda:
            flash('Cliente e data são obrigatórios', 'error')
            return redirect(url_for('nova_venda'))
        
        venda = Venda(
            cliente_id=cliente_id,
            data_venda=datetime.strptime(data_venda, '%Y-%m-%d').date()
        )
        
        livro_ids = request.form.getlist('livro_id')
        quantidades = request.form.getlist('quantidade')
        precos = request.form.getlist('preco')
        
        valor_total = Decimal('0')
        for livro_id, quantidade, preco in zip(livro_ids, quantidades, precos):
            if livro_id and quantidade and preco:
                item = VendaItem(
                    livro_id=livro_id,
                    quantidade=int(quantidade),
                    preco_unitario=Decimal(preco)
                )
                venda.itens.append(item)
                valor_total += Decimal(quantidade) * Decimal(preco)
        
        venda.valor_total = valor_total
        db.session.add(venda)
        db.session.commit()
        flash('Venda criada com sucesso!', 'success')
        return redirect(url_for('listar_vendas'))
    
    clientes = Cliente.query.all()
    livros = Livro.query.all()
    return render_template('nova_venda.html', clientes=clientes, livros=livros)

@app.route('/vendas/<int:id>/deletar', methods=['POST'])
def deletar_venda(id):
    """Deletar venda"""
    venda = Venda.query.get_or_404(id)
    db.session.delete(venda)
    db.session.commit()
    flash('Venda deletada com sucesso!', 'success')
    return redirect(url_for('listar_vendas'))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)